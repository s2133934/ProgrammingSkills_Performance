void rinit(int ijkl);
float random_uniform(void);
