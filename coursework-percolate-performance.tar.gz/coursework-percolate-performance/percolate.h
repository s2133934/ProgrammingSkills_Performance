struct cluster
{
  int id;
  int size;
};

void percsort(struct cluster *list, int n);
